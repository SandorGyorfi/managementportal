function showFAQ() {
    const message = `
          How to Use the Login Page:
          1. Select your department from the drop-down menu.
          2. Enter your username.
          3. Enter your PIN Code.
          
          If you do not have a PIN, please contact the Management Portal
          Head Office on +4412345678.
      `;
  
    alert(message);
  }
  